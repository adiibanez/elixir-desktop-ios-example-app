{application,wx_ex,
             [{optional_applications,[]},
              {applications,[kernel,stdlib,elixir,logger,wx]},
              {description,"Elixir wrappers for the Erlang macros and records in the wx package"},
              {modules,['Elixir.WxEx','Elixir.WxEx.Constants.OpenGL',
                        'Elixir.WxEx.Constants.WxWidgets',
                        'Elixir.WxEx.Records',gl_constants,wx_constants]},
              {registered,[]},
              {vsn,"0.5.1"}]}.
