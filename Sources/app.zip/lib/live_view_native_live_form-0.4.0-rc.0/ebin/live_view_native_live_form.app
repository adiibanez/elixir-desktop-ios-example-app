{application,live_view_native_live_form,
             [{optional_applications,[]},
              {applications,[kernel,stdlib,elixir,logger,live_view_native]},
              {description,"LiveView Native LiveForm"},
              {modules,['Elixir.LiveViewNative.LiveForm',
                        'Elixir.LiveViewNative.LiveForm.Component']},
              {registered,[]},
              {vsn,"0.4.0-rc.0"}]}.
