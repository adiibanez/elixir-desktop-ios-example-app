{application,live_view_native_live_form,
             [{modules,['Elixir.LiveViewNative.LiveForm',
                        'Elixir.LiveViewNative.LiveForm.Component']},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir,logger,live_view_native]},
              {description,"LiveView Native LiveForm"},
              {registered,[]},
              {vsn,"0.4.0-rc.0"}]}.
