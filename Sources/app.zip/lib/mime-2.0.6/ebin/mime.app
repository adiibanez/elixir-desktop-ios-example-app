{application,mime,
             [{compile_env,[{mime,[extensions],error},
                            {mime,[suffixes],error},
                            {mime,[types],
                                  {ok,#{<<"text/styles">> => [<<"styles">>],
                                        <<"text/swiftui">> =>
                                            [<<"swiftui">>]}}}]},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir,logger]},
              {description,"A MIME type module for Elixir"},
              {modules,['Elixir.MIME']},
              {registered,[]},
              {vsn,"2.0.6"},
              {env,[]}]}.
