{application,debouncer,
             [{modules,['Elixir.Debouncer']},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir]},
              {description,"Debouncer is a flexible function call debouncer."},
              {registered,[]},
              {vsn,"0.1.8"},
              {mod,{'Elixir.Debouncer',[]}}]}.
