Dummy libselinux
